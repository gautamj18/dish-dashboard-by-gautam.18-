require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/dishhub';

async function start() {
  try {
    await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');
  } catch (err) {
    console.error('Mongo connection error', err);
    process.exit(1);
  }

  // attach simple health route
  app.get('/health', (req, res) => res.json({ ok: true }));

  // mount REST routes (no socket.io)
  const dishesRouter = require('./routes/dishes');
  app.use('/api/dishes', dishesRouter);

  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

start();

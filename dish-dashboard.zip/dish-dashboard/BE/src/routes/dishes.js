const express = require('express');
const router = express.Router();

const Dish = require('../models/dish.model');

// GET all dishes
router.get('/', async (req, res) => {
  try {
    const dishes = await Dish.find({}).sort({ createdAt: 1 }).lean();
    res.json(dishes);
  } catch (err) {
    console.error('GET /api/dishes error', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// PUT toggle published by dishId
const toggleHandler = async (req, res) => {
  const { dishId } = req.params;
  try {
    const updated = await Dish.findOneAndUpdate(
      { dishId },
      [{ $set: { isPublished: { $not: '$isPublished' } } }],
      { new: true }
    ).lean();

    if (!updated) return res.status(404).json({ error: 'Dish not found' });

    // No sockets: just respond with updated document
    res.json(updated);
  } catch (err) {
    console.error('PUT toggle error', err);
    res.status(500).json({ error: 'Server error' });
  }
};
router.put('/:dishId/toggle', toggleHandler);

module.exports = router;

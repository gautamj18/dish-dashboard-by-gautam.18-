# Dish Backend (BE folder)

This folder contains a simple Express + MongoDB backend for the Dish Hub dashboard. It exposes APIs to list dishes and toggle published state.

## Setup

1. Install dependencies

```powershell
cd "d:\Assignment\Dish Dashboard\dish-hub-main\diff"
npm install
```


2. Start server

```powershell
npm run dev
# or
npm start
```

The server will run on `http://localhost:4000` by default.

## API

- GET `/api/dishes` — returns all dishes
- PATCH `/api/dishes/:dishId/toggle` — toggles `isPublished` for the dish with `dishId` and returns the updated dish







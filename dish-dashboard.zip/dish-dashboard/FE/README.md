# Dish Hub — Frontend (FE)

A small Vite + React + TypeScript frontend for the Dish Hub dashboard.

This README explains how to install, run, and connect the frontend to the backend on Windows PowerShell.

**Prerequisites**
- Node.js 18+ (or latest LTS)
- npm (comes with Node) or a compatible package manager

**Folder**
This README is for the frontend folder located at `dish-dashboard/FE` (contains the Vite app and `package.json`).

## Quick Start (PowerShell)

Open PowerShell and run:

```powershell
npm install
npm run dev
```

The dev server uses Vite and will usually be available at `http://localhost:8080`.

## Build & Preview

To build a production bundle and preview it locally:

```powershell
cd .\dish-hub-main\dish-hub-main
npm run build
npm run preview
```

## Backend (API) — local development

A simple backend for this project lives in the `dash-dashboard/BE` folder at the repository root. By default the frontend expects the API at `http://localhost:4000/api/dishes` (see `.env`).

To run the backend locally (from workspace root):

```powershell
cd .\BE
npm install
npm run dev
```

Server default: `http://localhost:4000`.

## Environment

The frontend reads `VITE_API_BASE_URL` from the `.env` file at the frontend folder root. Example (already provided in repo):

```text
VITE_API_BASE_URL="http://localhost:4000/api/dishes"
```

If your backend runs at a different host/port, update that value and restart the Vite server.

## Notes & Troubleshooting
- If CORS errors occur, ensure the backend `cors()` middleware is enabled (the included backend already enables it).
- If the frontend can't reach the API, verify the backend is running and the URL in `.env` is correct.
- Use the browser devtools / network tab to inspect API requests.

## Next steps I can help with
- Start both servers and verify the dashboard loads.
- Update the root README with unified instructions for FE + BE.
- Create an npm script to start frontend + backend concurrently.



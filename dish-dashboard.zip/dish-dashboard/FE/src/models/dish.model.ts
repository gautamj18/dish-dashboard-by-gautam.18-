// MongoDB Mongoose Schema for Dish
// This will be used in the backend

export interface DishDocument {
  dishId: string;
  dishName: string;
  imageUrl: string;
  isPublished: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

// Mongoose Schema definition (for backend implementation)
export const DishSchema = {
  dishId: {
    type: 'String',
    required: true,
    unique: true,
    index: true
  },
  dishName: {
    type: 'String',
    required: true,
    trim: true
  },
  imageUrl: {
    type: 'String',
    required: true
  },
  isPublished: {
    type: 'Boolean',
    required: true,
    default: false
  }
};

// Example Mongoose model definition:
/*
import mongoose from 'mongoose';

const dishSchema = new mongoose.Schema({
  dishId: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  dishName: {
    type: String,
    required: true,
    trim: true
  },
  imageUrl: {
    type: String,
    required: true
  },
  isPublished: {
    type: Boolean,
    required: true,
    default: false
  }
}, {
  timestamps: true
});

export const Dish = mongoose.model('Dish', dishSchema);
*/

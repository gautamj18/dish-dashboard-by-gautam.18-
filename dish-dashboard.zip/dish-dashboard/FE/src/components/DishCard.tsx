import { Dish } from "@/types/dish";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Eye, EyeOff, ShoppingCart  } from "lucide-react";

interface DishCardProps {
  dish: Dish;
  onTogglePublished: (dishId: string) => void;
  production?: boolean;
}

export const DishCard = ({ dish, onTogglePublished, production }: DishCardProps) => {
  return (
    <Card className="group overflow-hidden border-border bg-card transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl hover:shadow-primary/20">
      <div className="relative aspect-[4/3] w-full overflow-hidden">
        <img
          src={dish.imageUrl}
          alt={dish.dishName}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-black/0" />
        {!production && (
          <Badge 
          variant={dish.isPublished ? "default" : "secondary"}
          className="absolute right-3 top-3 bg-background/80 backdrop-blur-sm"
        >
          {dish.isPublished ? "Published" : "Draft"}
        </Badge>
        )}
      </div>
      <div className="space-y-4 p-5">
        <div>
          <h3 className={`text-xl font-semibold text-foreground ${production && ("text-center")}`}>{dish.dishName}</h3>
          {!production &&<p className="mt-1 text-xs text-muted-foreground">ID: {dish.dishId}</p>}
        </div>
        <Button
          onClick={!production ? () => onTogglePublished(dish.dishId) : undefined}
          variant={dish.isPublished ? "outline" : "default"}
          className="w-full transition-all duration-200"
          size="lg"
        >
          {!production && (dish.isPublished ? (
            <>
              <EyeOff className="mr-2 h-4 w-4" />
              Unpublish
            </>
          ) : (
            <>
              <Eye className="mr-2 h-4 w-4" />
              Publish
            </>
          ))}
          {production && (
            <>
             <ShoppingCart className="mr-2 h-4 w-4"/>
              Add to cart
            </>
          )}
        </Button>
      </div>
    </Card>
  );
};

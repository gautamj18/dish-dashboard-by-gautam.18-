import { Link } from "react-router-dom";
import { useDishes } from "@/hooks/useDishes";
import { DishCard } from "@/components/DishCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft } from "lucide-react";

const AllProducts = () => {
  const { dishes, loading, togglePublished, refreshDishes } = useDishes();

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card p-6">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/dashboard">
              <Button variant="ghost" size="sm" className="mr-4">
                <ChevronLeft className="h-4 w-4" />
                Dashboard
              </Button>
            </Link>
            <h2 className="text-2xl font-bold">All Products</h2>
          </div>
          <div>
            <Button onClick={refreshDishes} variant="outline">Refresh</Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {loading ? (
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="aspect-[4/3] w-full rounded-2xl" />
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-12 w-full rounded-lg" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {dishes.map((dish) => (
              dish.isPublished && <DishCard key={dish.dishId} dish={dish} onTogglePublished={togglePublished} production={true}/>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default AllProducts;

import { useDishes } from "@/hooks/useDishes";
import { DishCard } from "@/components/DishCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { RefreshCw, ChefHat } from "lucide-react";

const Index = () => {
  const { dishes, loading, togglePublished, refreshDishes } = useDishes();

  const publishedCount = dishes.filter(d => d.isPublished).length;

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Header */}
      <header className="border-b border-border bg-gradient-to-r from-card via-card to-card/80">
        <div className="container mx-auto px-4 py-12">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
                <ChefHat className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-foreground">Dish Management</h1>
                <p className="mt-2 text-lg text-muted-foreground">
                  Curate your culinary masterpieces
                </p>
              </div>
            </div>
            <Button 
              onClick={refreshDishes} 
              variant="outline"
              size="lg"
              className="gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        {loading ? (
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="aspect-[4/3] w-full rounded-2xl" />
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-12 w-full rounded-lg" />
              </div>
            ))}
          </div>
        ) : (
          <>
            {/* Stats Bar */}
            <div className="mb-8 flex items-center justify-between rounded-2xl border border-border bg-card p-6">
              <div>
                <p className="text-sm text-muted-foreground">Total Dishes</p>
                <p className="text-3xl font-bold text-foreground">{dishes.length}</p>
              </div>
              <div className="h-12 w-px bg-border" />
              <div>
                <p className="text-sm text-muted-foreground">Published</p>
                <p className="text-3xl font-bold text-primary">{publishedCount}</p>
              </div>
              <div className="h-12 w-px bg-border" />
              <div>
                <p className="text-sm text-muted-foreground">Drafts</p>
                <p className="text-3xl font-bold text-muted-foreground">
                  {dishes.length - publishedCount}
                </p>
              </div>
            </div>

            {/* Dish Grid */}
            <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {dishes.map((dish) => (
                <DishCard
                  key={dish.dishId}
                  dish={dish}
                  onTogglePublished={togglePublished}
                />
              ))}
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default Index;

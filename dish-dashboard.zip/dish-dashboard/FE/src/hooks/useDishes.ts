import { useState, useEffect } from "react";
import { Dish } from "@/types/dish";
import { dishService } from "@/services/dishService";
import { toast } from "sonner";

export const useDishes = () => {
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [loading, setLoading] = useState(true);

  // Load dishes from API
  const loadDishes = async () => {
    try {
      setLoading(true);
      const data = await dishService.getAllDishes();
      setDishes(data);
    } catch (error) {
      toast.error("Failed to load dishes");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDishes();
  }, []);

  const togglePublished = async (dishId: string) => {
    try {
      const updatedDish = await dishService.togglePublished(dishId);
      if (updatedDish) {
        // Optimistic update
        setDishes(prev => 
          prev.map(dish => 
            dish.dishId === dishId 
              ? { ...dish, isPublished: !dish.isPublished }
              : dish
          )
        );
        toast.success(
          `${updatedDish.dishName} ${updatedDish.isPublished ? "published" : "unpublished"}`
        );
      }
    } catch (error) {
      toast.error("Failed to update dish");
      console.error(error);
    }
  };

  return {
    dishes,
    loading,
    togglePublished,
    refreshDishes: loadDishes
  };
};

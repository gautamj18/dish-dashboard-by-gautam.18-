// MongoDB connection configuration
// This will be used in the backend API

export const dbConfig = {
  // Add your MongoDB connection string here when backend is ready
  connectionString: process.env.MONGODB_URI || '',
  dbName: 'dishManagement',
  collections: {
    dishes: 'dishes'
  }
};

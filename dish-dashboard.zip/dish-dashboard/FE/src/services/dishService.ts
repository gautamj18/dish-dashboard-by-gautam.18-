import { Dish } from "@/types/dish";

const API_BASE_URL: string = (import.meta.env.VITE_API_BASE_URL as string) ?? "/api/dishes";

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    const message = text || res.statusText || `HTTP ${res.status}`;
    throw new Error(message);
  }
  return (await res.json()) as T;
}

export const dishService = {
  // GET all dishes
  getAllDishes: async (): Promise<Dish[]> => {
    const res = await fetch(API_BASE_URL, {
      method: "GET",
      headers: { "Content-Type": "application/json" }
    });
    return handleResponse<Dish[]>(res);
  },
  
  // Toggle published state - expects backend endpoint to toggle and return updated dish
  togglePublished: async (dishId: string): Promise<Dish> => {
    const res = await fetch(`${API_BASE_URL}/${encodeURIComponent(dishId)}/toggle`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" }
    });
    return handleResponse<Dish>(res);
  }
};
